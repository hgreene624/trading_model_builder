import streamlit as st
import pandas as pd
from datetime import date, timedelta
from src.models.atr_breakout import backtest_single
from src.storage import list_portfolios, create_portfolio, add_item

st.set_page_config(page_title="Ticker Selector & Tuning", page_icon="🧪")

st.title("🧪 Ticker Selector & Model Tuning")

with st.sidebar:
    st.markdown("**Model: ATR Breakout**")
    breakout_n = st.slider("Breakout lookback (days)", 10, 200, 55, 1)
    exit_n = st.slider("Exit lookback (days)", 5, 100, 20, 1)
    atr_n = st.slider("ATR lookback (days)", 5, 50, 14, 1)
    starting_equity = st.number_input("Starting Equity ($)", min_value=1000, value=10_000, step=500)

colA, colB = st.columns(2)
with colA:
    symbol = st.text_input("Ticker", value="AAPL").upper().strip()
with colB:
    end = st.date_input("End Date", value=date.today())
    start = st.date_input("Start Date", value=end - timedelta(days=365*3))

if st.button("Run Single-Ticker Backtest", type="primary"):
    with st.spinner("Backtesting..."):
        try:
            res = backtest_single(symbol, start.isoformat(), end.isoformat(), breakout_n, exit_n, atr_n, starting_equity)
            equity = res["equity"]
            metrics = res["metrics"]
            st.subheader(f"Results — {symbol}")
            st.line_chart(equity, height=300)
            st.write(pd.DataFrame([metrics]))
            st.success("Done.")
            st.session_state["last_result"] = {"symbol": symbol, "params": {"breakout_n":breakout_n,"exit_n":exit_n,"atr_n":atr_n}}
        except Exception as e:
            st.error(f"Error: {e}")

st.divider()
st.subheader("Save this configuration to a Portfolio")
portfolios = list_portfolios()
names = ["— Create new —"] + [p["name"] for p in portfolios]
choice = st.selectbox("Target Portfolio", names, index=1 if len(portfolios)>0 else 0)
new_name = ""
if choice == "— Create new —":
    new_name = st.text_input("New Portfolio Name", value="My Portfolio")

if st.button("Save to Portfolio"):
    last = st.session_state.get("last_result")
    if not last:
        st.warning("Run a backtest first.")
    else:
        if choice == "— Create new —":
            if not new_name.strip():
                st.warning("Please provide a name for the new portfolio.")
            else:
                p = create_portfolio(new_name.strip())
                add_item(p["id"], last["symbol"], "atr_breakout", last["params"])
                st.success(f"Saved {last['symbol']} to portfolio '{p['name']}'.")
        else:
            pid = next((p["id"] for p in portfolios if p["name"] == choice), None)
            if pid:
                add_item(pid, last["symbol"], "atr_breakout", last["params"])
                st.success(f"Saved {last['symbol']} to portfolio '{choice}'.")
            else:
                st.error("Portfolio not found.")
